#!/bin/bash

PROCENT=$(df -h | grep "/dev/vda2" | awk {'print $5'}) # Команда выводит процент занятого места в корневой партиции
PROCENT=${PROCENT::-1} # Команда отрезает последий символ, в нашем случае символ '%'
if [[ $PROCENT -gt 60 ]]  # Условие, где если процент занятого места в корневой партиции больше 60, то делаем следующие действия:
then
	echo "less than 60% free space. Currently used $PROCENT %" # Оповещаем о ситуации, все это будет в логах
	truncate -s 0 /var/log/syslog # Чистим но не удаляем файл syslog
	rm -f /var/log/syslog.* # Удаляем все файлы syslog.*
	apt clean # Чистим кэш apt
elif [[ $PROCENT -lt 60 ]] # Условие если процент занятого места в корневой партиции меньше 60:
then
	echo "More than 60% free space in the root partition. Currently used $PROCENT %" # Уведомляем что места достаточно
else
	echo "ERROR. Oops, something went wrong" # Ну и на всякий случай если что то пойдет не так
fi
