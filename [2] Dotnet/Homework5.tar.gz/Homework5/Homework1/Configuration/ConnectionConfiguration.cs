﻿namespace Homework1.Configuration
{
    public class ConnectionConfiguration
    {
        public string CurrencyConnection { get; set; }
    }
}
