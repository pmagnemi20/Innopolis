﻿namespace Homework1.Logging
{
    public class DbLoggerConfiguration
    {
        public string DbConnectionString { get; set; }
    }
}
