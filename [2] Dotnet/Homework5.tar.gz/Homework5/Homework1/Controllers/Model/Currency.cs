﻿namespace Homework1.Controllers.Model
{
    public class Currency
    {
        public int Id { get; set; }
        public double Price { get; set; }
        public string? CurrencyCode { get; set; }
        public string? Date { get; set; }
        public int Value { get; set; }
    }
}
